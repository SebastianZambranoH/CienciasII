package hilos.mavenproject3;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

public class ArbolB {
    public Nodo raiz;
    public final int gradoMinimo; //(t)

    public ArbolB(int gradoMinimo) {
        this.raiz = null;
        this.gradoMinimo = gradoMinimo;
    }

    // Buscar una clave en el árbol
    public Nodo busqueda(int k) {
        return (raiz == null) ? null : raiz.busqueda(k);
    }

    // Insertar una nueva clave
    public void insercion(int k) {
        if (raiz == null) {
            // Si el árbol está vacío, crear la raíz como hoja
            raiz = new Nodo(gradoMinimo, true);
            raiz.claves.add(k);
        } else {
            // Si la raíz está llena (capacidad máxima: 2 * gradoMinimo - 1)
            if (raiz.claves.size() == (2 * gradoMinimo - 1)) {
                Nodo s = new Nodo(gradoMinimo, false);
                s.hijos.add(raiz); // La antigua raíz se vuelve hijo de la nueva

                // Dividir el hijo antiguo y subir la clave del medio a la nueva raíz
                dividirHijos(s, 0, raiz);

                // Decidir en cuál de los dos nuevos hijos insertar la clave k
                int i = 0;
                if (s.claves.get(0) < k) {
                    i++;
                }
                insercionNoLleno(s.hijos.get(i), k);

                raiz = s; // Actualizar la raíz
            } else {
                // Si la raíz no está llena, insertar normalmente
                insercionNoLleno(raiz, k);
            }
        }
    }
    
    public void mostrarArbol() {
        if (raiz != null){
            raiz.imprimirFormato("", true);
        } else {
            System.out.println("El arbol esta vacio");
        }
}

    // Insertar en un nodo que tiene espacio disponible
    public void insercionNoLleno(Nodo x, int k) {
        int i = x.claves.size() - 1;

        if (x.hoja) {
            // Si es hoja, encontrar la posición correcta e insertar directamente
            while (i >= 0 && x.claves.get(i) > k) {
                i--;
            }
            x.claves.add(i + 1, k);
        } else {
            // Si es nodo interno, encontrar el hijo por el que se debe descender
            while (i >= 0 && x.claves.get(i) > k) {
                i--;
            }
            i++;

            // Si el hijo está lleno, dividirlo primero
            if (x.hijos.get(i).claves.size() == (2 * gradoMinimo - 1)) {
                dividirHijos(x, i, x.hijos.get(i));

                // Después de dividir, evaluar cuál de los dos nuevos hijos recibe la clave k
                if (x.claves.get(i) < k) {
                    i++;
                }
            }
            insercionNoLleno(x.hijos.get(i), k);
        }
    }

    // Dividir el nodo hijo 'y' del nodo padre 'x'
    public void dividirHijos(Nodo x, int i, Nodo y) {
        // Crear un nuevo nodo hermano 'z' del mismo tipo que 'y'
        Nodo z = new Nodo(y.gradoMinimo, y.hoja);

        // Pasar las últimas (gradoMinimo - 1) claves de 'y' a 'z'
        for (int j = gradoMinimo; j < 2 * gradoMinimo - 1; j++) {
            z.claves.add(y.claves.get(gradoMinimo));
            y.claves.remove(gradoMinimo); 
        }

        // Si 'y' no es hoja, también debemos pasar sus últimos 'gradoMinimo' hijos a 'z'
        if (!y.hoja) {
            for (int j = gradoMinimo; j < 2 * gradoMinimo; j++) {
                z.hijos.add(y.hijos.get(gradoMinimo));
                y.hijos.remove(gradoMinimo);
            }
        }

        // Agregar el nuevo hijo 'z' al nodo padre 'x' en la posición correspondiente
        x.hijos.add(i + 1, z);

        // Subir la clave mediana de 'y' al nodo padre 'x'
        x.claves.add(i, y.claves.get(gradoMinimo - 1));
        y.claves.remove(gradoMinimo - 1); // Removerla de 'y' definitivamente
    }

    // Método principal para probar el funcionamiento
    public static void main(String[] args) {
        ArbolB t = new ArbolB(3); // Grado mínimo = 3 (Capacidad máxima por nodo = 5 claves)
        int[] datos = {10, 20, 5, 6, 12, 30, 7, 17, 3, 4, 8, 9, 22, 25}; 

        for (int numero : datos){
            t.insercion(numero);
        }
        
        t.insercion(40);
        
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        
        System.out.println("Estructura Visual");
        t.mostrarArbol();
        
        System.out.println("Búsqueda de la clave 40:");
        Nodo res = t.busqueda(12);
        System.out.println(res != null ? "Clave encontrada exitosamente." : "Clave no encontrada.");

        System.out.println("\nBúsqueda de la clave 99:");
        res = t.busqueda(99);
        System.out.println(res != null ? "Clave encontrada exitosamente." : "Clave no encontrada.");
    }
}
