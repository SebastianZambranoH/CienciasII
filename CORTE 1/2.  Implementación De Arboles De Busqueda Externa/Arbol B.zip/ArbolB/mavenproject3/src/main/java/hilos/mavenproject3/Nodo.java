package hilos.mavenproject3;
import java.util.ArrayList;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

// Clase que representa un Nodo del Árbol B
public class Nodo {
    ArrayList<Integer> claves; // Lista de claves
    ArrayList<Nodo> hijos; // Lista de punteros a los hijos
    int gradoMinimo; // Grado mínimo (t)
    boolean hoja; // Verdadero si es hoja

    // Constructor del nodo
    public Nodo(int gradoMinimo, boolean hoja) {
        this.gradoMinimo = gradoMinimo;
        this.hoja = hoja;
        this.claves = new ArrayList<>();
        this.hijos = new ArrayList<>();
    }

    // Buscar una clave en el subárbol
    public Nodo busqueda(int k) {
        int i = 0;
        // Avanzar mientras la clave actual sea menor que k
        while (i < claves.size() && k > claves.get(i)) {
            i++;
        }

        // Si la encontramos en este nodo, lo retornamos
        if (i < claves.size() && claves.get(i) == k) {
            return this;
        }

        // Si es hoja y no se encontró, no existe en el árbol
        if (hoja) {
            return null;
        }

        // Buscar en el hijo correspondiente
        return hijos.get(i).busqueda(k);
    }
    
    public void imprimirFormato (String prefijo, boolean esUltimo){
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        System.out.print(prefijo);
        System.out.print(esUltimo ? "└──  " : "├──  ");
        System.out.println(claves);
        
        if(!hoja){
            for (int i = 0; i<hijos.size(); i++){
                String nuevoPrefijo = prefijo + (esUltimo ? "  " : "│   ");
                boolean ultimoHijo = (i == hijos.size() - 1);
                hijos.get(i).imprimirFormato(nuevoPrefijo, ultimoHijo);
            }
        }
    }
}